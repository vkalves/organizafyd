# Storys Com Link (v0.8.0 - Multi-Contas)

Extensão local Manifest V3 com editor de Stories, sticker de link clicável e suporte a **postar em todas as contas conectadas simultaneamente** integrado ao Instagram Web.

## Novidades na v0.8.0

- **Multi-Contas Simultâneo**: Publique o mesmo Story com sticker clicável em todas as contas conectadas ao mesmo tempo com 1 clique.
- **Detecção Automática**: Detecta as contas salvas no alternador de contas do Instagram Web ("Trocar de conta").
- **Aba Contas**: Visualize as contas disponíveis, ative o envio em lote para todas ou selecione apenas as contas desejadas.
- **Destaque em Lote**: Criação de Destaque automático em cada conta selecionada.

## Instalação

1. Abra `chrome://extensions` (ou `edge://extensions`).
2. Ative o **Modo do desenvolvedor** no canto superior direito.
3. Clique em **Carregar sem compactação**.
4. Selecione a pasta extraída contendo o arquivo `manifest.json`.
5. Abra ou atualize o Instagram Web (`https://www.instagram.com`).
6. Clique no botão da extensão ou no menu lateral "Criar Story".

## Como Usar o Multi-Contas

1. No Instagram Web, adicione suas contas clicando em **Mais** > **Trocar de conta** > **Entrar em uma conta existente**.
2. Abra o **Storys Com Link**.
3. Selecione a foto e configure a URL do seu link e o texto do sticker.
4. Na aba **👥 Contas**, confirme se todas as contas estão marcadas (ou selecione as desejadas).
5. Clique em **PUBLICAR EM TODAS AS CONTAS**.
6. A extensão publicará o Story em cada conta conectada e exibirá a confirmação.

## Privacidade

A extensão opera diretamente no seu navegador, sem servidores externos intermediários. Toda a comunicação acontece direto entre o seu navegador e a API oficial do Instagram.
