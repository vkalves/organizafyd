(function () {
  // Always clean up any old v0.5.0 / v0.6.0 modal or launcher in the open tab
  const oldFab = document.getElementById("organizafy-story-link-fab");
  if (oldFab && oldFab.getAttribute("data-ver") !== "0.7.0") {
    oldFab.remove();
  }
  const oldModal = document.getElementById("organizafy-story-link-modal");
  if (oldModal && oldModal.getAttribute("data-ver") !== "0.7.0") {
    oldModal.remove();
  }

  if (window.__ORGANIZAFY_STORY_LINK_V7__) return;
  window.__ORGANIZAFY_STORY_LINK_V7__ = true;

  document.documentElement.setAttribute("data-organizafy-story-link-ext", "0.7.0");
  window.postMessage({ type: "ORGANIZAFY_EXT_READY", version: "0.7.0" }, "*");

  // Bridge for Organizafy / Agonia Web Panel (/agonia/stories-link)
  window.addEventListener("message", (event) => {
    if (event.source !== window || !event.data) return;

    if (event.data.type === "ORGANIZAFY_EXT_PING") {
      window.postMessage({ type: "ORGANIZAFY_EXT_READY", version: "0.7.0" }, "*");
      return;
    }

    if (event.data.type === "ORGANIZAFY_EXT_PUBLISH_STORY") {
      const reqId = event.data.requestId;
      chrome.runtime.sendMessage(
        {
          type: "PUBLISH_IG_STORY_WITH_LINK",
          payload: event.data.payload
        },
        (response) => {
          const runtimeErr = chrome.runtime.lastError;
          if (runtimeErr) {
            window.postMessage(
              {
                type: "ORGANIZAFY_EXT_PUBLISH_RESULT",
                requestId: reqId,
                ok: false,
                error: runtimeErr.message
              },
              "*"
            );
            return;
          }
          window.postMessage(
            {
              type: "ORGANIZAFY_EXT_PUBLISH_RESULT",
              requestId: reqId,
              ...(response || { ok: false, error: "Sem resposta da extensão." })
            },
            "*"
          );
        }
      );
    }
  });

  if (!location.hostname.includes("instagram.com")) {
    return;
  }

  function drawRoundedRect(ctx, x, y, width, height, radius) {
    const r = Math.min(radius, width / 2, height / 2);
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + width, y, x + width, y + height, r);
    ctx.arcTo(x + width, y + height, x, y + height, r);
    ctx.arcTo(x, y + height, x, y, r);
    ctx.arcTo(x, y, x + width, y, r);
    ctx.closePath();
  }

  function drawChainLinkVector(ctx, cx, cy, scaleFactor, color) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(-Math.PI / 4);
    const s = (scaleFactor * 36) / 24;
    ctx.scale(s, s);
    ctx.translate(-12, -12);
    ctx.strokeStyle = color;
    ctx.lineWidth = 2.5;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    ctx.stroke(new Path2D("M9 17H7A5 5 0 0 1 7 7h2"));
    ctx.stroke(new Path2D("M15 7h2a5 5 0 1 1 0 10h-2"));
    ctx.stroke(new Path2D("M8 12h8"));
    ctx.restore();
  }

  function createLauncher() {
    let fab = document.getElementById("organizafy-story-link-fab");
    if (fab) return;
    fab = document.createElement("button");
    fab.id = "organizafy-story-link-fab";
    fab.setAttribute("data-ver", "0.7.0");
    fab.textContent = "🔗 Story com Link (v0.7.0)";
    Object.assign(fab.style, {
      position: "fixed",
      bottom: "22px",
      right: "22px",
      zIndex: "999998",
      background: "#2ea8ff",
      color: "#fff",
      border: "none",
      borderRadius: "999px",
      padding: "10px 18px",
      fontWeight: "700",
      fontSize: "13px",
      cursor: "pointer",
      boxShadow: "0 10px 28px rgba(0,0,0,0.45)"
    });
    fab.addEventListener("click", () => openModal());
    document.body.appendChild(fab);
  }

  let modalEl = null;
  function openModal() {
    const existing = document.getElementById("organizafy-story-link-modal");
    if (existing) {
      existing.style.display = "flex";
      return;
    }

    modalEl = document.createElement("div");
    modalEl.id = "organizafy-story-link-modal";
    modalEl.setAttribute("data-ver", "0.7.0");
    Object.assign(modalEl.style, {
      position: "fixed",
      inset: "0",
      zIndex: "999999",
      background: "rgba(0,0,0,0.84)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "-apple-system, BlinkMacSystemFont, Segoe UI, Roboto, sans-serif"
    });

    modalEl.innerHTML = `
      <div style="width:940px;max-width:96vw;background:#202328;color:#f4f4f5;border-radius:14px;display:grid;grid-template-columns:1.1fr 1fr;overflow:hidden;border:1px solid rgba(255,255,255,0.12);box-shadow:0 24px 64px rgba(0,0,0,0.65);">
        <div style="padding:18px;display:flex;flex-direction:column;gap:14px;border-right:1px solid rgba(255,255,255,0.08);">
          <div id="ogz-stage" style="position:relative;height:520px;background:#0e1013;border-radius:10px;display:flex;align-items:center;justify-content:center;overflow:hidden;user-select:none;">
            <div id="ogz-aspect" style="position:relative;height:100%;aspect-ratio:9/16;background:#161920;overflow:hidden;display:flex;align-items:center;justify-content:center;">
              <canvas id="ogz-live-canvas" width="1080" height="1920" style="width:100%;height:100%;display:block;cursor:grab;touch-action:none;"></canvas>
              <button id="ogz-download" type="button" title="Baixar imagem 1080x1920 com sticker" style="position:absolute;top:16px;left:50%;transform:translateX(-50%);width:36px;height:36px;border-radius:999px;background:rgba(255,255,255,0.92);color:#1d6ff2;border:none;font-size:16px;font-weight:800;cursor:pointer;box-shadow:0 6px 16px rgba(0,0,0,0.3);">⬇</button>
              <div id="ogz-empty" style="position:absolute;inset:0;display:flex;align-items:center;justify-content:center;text-align:center;color:#d1d5db;font-size:13px;padding:24px;cursor:pointer;background:rgba(14,16,19,0.55);">Clique aqui ou no botão <b>+</b> abaixo para escolher a foto 9:16</div>
            </div>
          </div>
          <div style="display:flex;align-items:center;gap:10px;">
            <input id="ogz-file" type="file" accept="image/jpeg,image/png,image/webp" style="display:none;" />
            <button id="ogz-add" type="button" style="width:42px;height:42px;border-radius:8px;background:#2b2f36;color:#e5e7eb;border:1px solid rgba(255,255,255,0.1);font-size:22px;cursor:pointer;">+</button>
            <span id="ogz-filename" style="font-size:12px;color:#9ca3af;"></span>
          </div>
          <div style="display:flex;align-items:center;gap:14px;padding-top:6px;border-top:1px solid rgba(255,255,255,0.08);">
            <button id="ogz-publish" type="button" style="background:#2ea8ff;color:#fff;border:none;border-radius:8px;padding:12px 22px;font-weight:800;font-size:13px;cursor:pointer;line-height:1.25;">PUBLICAR<br/>STORY</button>
            <div id="ogz-status" style="font-size:12px;color:#9ca3af;line-height:1.4;">v0.7.0 ativo: O botão do sticker é gravado direto na imagem + link clicável!</div>
          </div>
        </div>
        <div style="padding:20px;display:flex;flex-direction:column;gap:15px;position:relative;">
          <button id="ogz-close" type="button" style="position:absolute;top:14px;right:16px;background:none;border:none;color:#9ca3af;font-size:22px;cursor:pointer;">×</button>
          <div style="display:flex;gap:18px;border-bottom:1px solid rgba(255,255,255,0.08);padding-bottom:10px;font-weight:700;font-size:13px;">
            <span style="color:#9ca3af;">POST</span>
            <span style="color:#9ca3af;">REEL</span>
            <span style="color:#fff;border-bottom:2px solid #fff;padding-bottom:8px;margin-bottom:-11px;">● STORY (v0.7.0)</span>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap;">
            <span style="background:#2ea8ff;color:#fff;padding:7px 14px;border-radius:8px;font-size:12px;font-weight:700;">🔗 Link + Sticker Visual</span>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <label style="font-size:12px;font-weight:700;color:#d1d5db;">URL</label>
            <input id="ogz-url" type="url" value="https://privame.site/nicolle" style="background:#181a1f;border:1px solid rgba(255,255,255,0.12);border-radius:8px;padding:11px 12px;color:#fff;font-size:13px;" />
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <label style="font-size:12px;font-weight:700;color:#d1d5db;">Texto do sticker</label>
            <input id="ogz-text" type="text" value="CLIQUE AQUI AMOR ♥" style="background:#181a1f;border:1px solid rgba(255,255,255,0.12);border-radius:8px;padding:11px 12px;color:#fff;font-size:13px;" />
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <label style="font-size:12px;font-weight:700;color:#d1d5db;">Estilo</label>
            <select id="ogz-style" style="background:#181a1f;border:1px solid rgba(255,255,255,0.12);border-radius:8px;padding:11px 12px;color:#fff;font-size:13px;">
              <option value="blue">Azul</option>
              <option value="white">Branco</option>
              <option value="dark">Escuro</option>
              <option value="pink">Rosa / VIP</option>
              <option value="green">Verde</option>
            </select>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <label style="font-size:12px;font-weight:700;color:#d1d5db;">Tamanho do sticker</label>
            <div style="display:flex;align-items:center;gap:10px;font-size:12px;color:#9ca3af;">
              <span>Pequeno</span>
              <input id="ogz-size" type="range" min="55" max="145" value="92" style="flex:1;" />
              <span>Grande</span>
            </div>
            <div id="ogz-size-val" style="text-align:right;font-size:12px;font-weight:700;color:#fff;">92%</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:6px;">
            <label style="font-size:12px;font-weight:700;color:#d1d5db;">Texto extra opcional (topo)</label>
            <input id="ogz-extra-text" type="text" placeholder="Opcional..." style="background:#181a1f;border:1px solid rgba(255,255,255,0.12);border-radius:8px;padding:10px 12px;color:#fff;font-size:13px;" />
          </div>
          <p style="font-size:12px;color:#9ca3af;margin:0;">Arraste o sticker diretamente na imagem para posicioná-lo.</p>
        </div>
      </div>
    `;

    document.body.appendChild(modalEl);

    let loadedImage = null;
    let posX = 0.5;
    let posY = 0.74;
    let lastPillW = 540;
    let lastPillH = 98;
    let dragging = false;

    const liveCanvas = modalEl.querySelector("#ogz-live-canvas");
    const fileInput = modalEl.querySelector("#ogz-file");
    const emptyEl = modalEl.querySelector("#ogz-empty");
    const urlInput = modalEl.querySelector("#ogz-url");
    const textInput = modalEl.querySelector("#ogz-text");
    const styleSelect = modalEl.querySelector("#ogz-style");
    const sizeInput = modalEl.querySelector("#ogz-size");
    const sizeVal = modalEl.querySelector("#ogz-size-val");
    const extraTextInput = modalEl.querySelector("#ogz-extra-text");
    const statusEl = modalEl.querySelector("#ogz-status");

    function renderLiveCanvas() {
      const ctx = liveCanvas.getContext("2d");
      const grad = ctx.createLinearGradient(0, 0, 0, 1920);
      grad.addColorStop(0, "#182032");
      grad.addColorStop(1, "#0d1018");
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 1080, 1920);

      if (loadedImage) {
        const scale = Math.max(
          1080 / loadedImage.naturalWidth,
          1920 / loadedImage.naturalHeight
        );
        const w = loadedImage.naturalWidth * scale;
        const h = loadedImage.naturalHeight * scale;
        ctx.drawImage(loadedImage, (1080 - w) / 2, (1920 - h) / 2, w, h);
      }

      const extraTxt = (extraTextInput.value || "").trim();
      if (extraTxt) {
        ctx.save();
        ctx.font = '700 44px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        const m = ctx.measureText(extraTxt);
        const bw = Math.min(980, m.width + 68);
        const bh = 88;
        ctx.fillStyle = "rgba(12, 12, 16, 0.78)";
        drawRoundedRect(ctx, 540 - bw / 2, 340 - bh / 2, bw, bh, 24);
        ctx.fill();
        ctx.fillStyle = "#ffffff";
        ctx.fillText(extraTxt, 540, 340);
        ctx.restore();
      }

      // Draw Sticker Pill directly onto liveCanvas
      const label = (textInput.value || "CLIQUE AQUI").trim().toUpperCase();
      const scaleFactor = Number(sizeInput.value) / 100;
      const fontSize = Math.round(38 * scaleFactor);
      ctx.font = `700 ${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
      const textMetrics = ctx.measureText(label);
      const iconSpace = Math.round(56 * scaleFactor);
      const padX = Math.round(42 * scaleFactor);
      const pillW = Math.min(980, Math.round(textMetrics.width + iconSpace + padX * 2));
      const pillH = Math.round(106 * scaleFactor);
      lastPillW = pillW;
      lastPillH = pillH;

      const cx = posX * 1080;
      const cy = posY * 1920;
      const pillX = Math.max(24, Math.min(1080 - pillW - 24, cx - pillW / 2));
      const pillY = Math.max(24, Math.min(1920 - pillH - 24, cy - pillH / 2));

      const st = styleSelect.value;
      const bg = st === "dark" ? "rgba(18,18,22,0.92)" : "#ffffff";
      const fg =
        st === "blue"
          ? "#1d6ff2"
          : st === "white"
            ? "#18181b"
            : st === "pink"
              ? "#e11d48"
              : st === "green"
                ? "#059669"
                : "#ffffff";

      ctx.save();
      ctx.shadowColor = "rgba(0,0,0,0.32)";
      ctx.shadowBlur = 28;
      ctx.shadowOffsetY = 10;
      ctx.fillStyle = bg;
      drawRoundedRect(ctx, pillX, pillY, pillW, pillH, pillH / 2);
      ctx.fill();
      ctx.restore();

      drawChainLinkVector(
        ctx,
        pillX + padX + Math.round(18 * scaleFactor),
        pillY + pillH / 2,
        scaleFactor,
        fg
      );

      ctx.save();
      ctx.fillStyle = fg;
      ctx.font = `700 ${fontSize}px -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif`;
      ctx.textAlign = "left";
      ctx.textBaseline = "middle";
      ctx.fillText(
        label,
        pillX + padX + iconSpace,
        pillY + pillH / 2 + Math.round(2 * scaleFactor)
      );
      ctx.restore();
    }

    renderLiveCanvas();

    modalEl.querySelector("#ogz-close").onclick = () => {
      modalEl.style.display = "none";
    };
    modalEl.querySelector("#ogz-add").onclick = () => fileInput.click();
    emptyEl.onclick = () => fileInput.click();

    modalEl.querySelector("#ogz-download").onclick = (e) => {
      e.stopPropagation();
      renderLiveCanvas();
      const a = document.createElement("a");
      a.href = liveCanvas.toDataURL("image/jpeg", 0.94);
      a.download = "story-com-link-" + Date.now() + ".jpg";
      document.body.appendChild(a);
      a.click();
      a.remove();
    };

    fileInput.onchange = (e) => {
      const f = e.target.files && e.target.files[0];
      if (!f) return;
      const objUrl = URL.createObjectURL(f);
      const img = new Image();
      img.onload = () => {
        loadedImage = img;
        emptyEl.style.display = "none";
        modalEl.querySelector("#ogz-filename").textContent = f.name;
        renderLiveCanvas();
      };
      img.src = objUrl;
    };

    textInput.oninput = () => renderLiveCanvas();
    styleSelect.onchange = () => renderLiveCanvas();
    extraTextInput.oninput = () => renderLiveCanvas();
    sizeInput.oninput = () => {
      sizeVal.textContent = sizeInput.value + "%";
      renderLiveCanvas();
    };

    liveCanvas.addEventListener("pointerdown", (e) => {
      if (!loadedImage) {
        fileInput.click();
        return;
      }
      dragging = true;
      const r = liveCanvas.getBoundingClientRect();
      if (r.width && r.height) {
        posX = Math.max(0.14, Math.min(0.86, (e.clientX - r.left) / r.width));
        posY = Math.max(0.08, Math.min(0.92, (e.clientY - r.top) / r.height));
        renderLiveCanvas();
      }
    });

    window.addEventListener("pointermove", (e) => {
      if (!dragging) return;
      const r = liveCanvas.getBoundingClientRect();
      if (!r.width || !r.height) return;
      posX = Math.max(0.14, Math.min(0.86, (e.clientX - r.left) / r.width));
      posY = Math.max(0.08, Math.min(0.92, (e.clientY - r.top) / r.height));
      renderLiveCanvas();
    });

    window.addEventListener("pointerup", () => {
      dragging = false;
    });

    modalEl.querySelector("#ogz-publish").onclick = async () => {
      if (!loadedImage) {
        statusEl.style.color = "#f87171";
        statusEl.textContent = "Escolha uma imagem clicando no botão + primeiro.";
        return;
      }
      if (!urlInput.value.trim()) {
        statusEl.style.color = "#f87171";
        statusEl.textContent = "Informe a URL do link.";
        return;
      }

      statusEl.style.color = "#38bdf8";
      statusEl.textContent =
        "Gravando botão do sticker na imagem 1080x1920 e publicando com link clicável...";

      try {
        renderLiveCanvas();
        const imageBase64 = liveCanvas.toDataURL("image/jpeg", 0.94);
        const label = (textInput.value || "CLIQUE AQUI").trim().toUpperCase();
        const widthNorm = Math.max(0.35, Math.min(0.85, lastPillW / 1080));
        const heightNorm = Math.max(0.06, Math.min(0.22, lastPillH / 1920));

        chrome.runtime.sendMessage(
          {
            type: "PUBLISH_IG_STORY_WITH_LINK",
            payload: {
              imageBase64,
              stickerBaked: true,
              linkUrl: urlInput.value.trim(),
              stickerText: label,
              stickerStyle: styleSelect.value,
              stickerSize: Number(sizeInput.value),
              xNorm: posX,
              yNorm: posY,
              widthNorm,
              heightNorm
            }
          },
          (response) => {
            const runtimeErr = chrome.runtime.lastError;
            if (runtimeErr) {
              statusEl.style.color = "#f87171";
              statusEl.textContent = runtimeErr.message;
              return;
            }
            if (response && response.ok) {
              statusEl.style.color = "#34d399";
              statusEl.textContent =
                "Story publicado com o BOTÃO DO STICKER visível + LINK CLICÁVEL ativo!";
            } else {
              statusEl.style.color = "#f87171";
              statusEl.textContent =
                (response && response.error) || "Não foi possível publicar o Story.";
            }
          }
        );
      } catch (err) {
        statusEl.style.color = "#f87171";
        statusEl.textContent = err instanceof Error ? err.message : String(err);
      }
    };
  }

  window.addEventListener("organizafy:toggle-story-link-modal", () => openModal());
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", createLauncher);
  } else {
    createLauncher();
  }
  if (location.search.includes("story_link_editor=1")) {
    setTimeout(openModal, 800);
  }
})();
