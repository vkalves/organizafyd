(() => {
  if (window.__storyLinkV3) return;
  window.__storyLinkV3 = true;
  document.querySelector("#storylink-root")?.remove();

  const state = {
    base64: "",
    file: null,
    imageUrl: "",
    x: .5,
    y: .82,
    width: .32,
    height: .039,
    stickerScale: 1,
    busy: false,
    accounts: [],
    selectedAccountIds: new Set(),
    postAllAccounts: true
  };

  const root = document.createElement("div");
  root.id = "storylink-root";
  root.innerHTML = `
    <div class="sl-create-menu" hidden>
      <div class="sl-menu-head"><span>Post Assistant</span><button type="button" data-kind="post">▧ Post</button><button type="button" data-kind="reel">▣ Reel</button><button type="button" data-kind="story">◉ Story</button></div>
      <button class="sl-menu-row" type="button" data-kind="story"><span>Publicar Story</span><b>▧</b></button>
      <button class="sl-menu-row muted" type="button"><span>Vídeo ao vivo</span><b>◉</b></button>
      <button class="sl-menu-row muted" type="button"><span>Anúncio</span><b>↗</b></button>
    </div>
    <div class="sl-backdrop" hidden>
      <section class="sl-dialog" role="dialog" aria-modal="true" aria-label="Editor de Story">
        <button class="sl-close" type="button" aria-label="Fechar">×</button>
        <div class="sl-canvas-column">
          <div class="sl-canvas">
            <div class="sl-empty"><b>Adicionar ao Story</b><span>Escolha uma foto para começar</span><button class="sl-choose" type="button">Selecionar foto</button></div>
            <img class="sl-photo" alt="Prévia do Story">
            <div class="sl-sticker" data-style="blue"><svg class="sl-link-icon" viewBox="-24 -24 48 48" fill="none" aria-hidden="true"><path d="M -17 -3.2 C -23 1.8 -23.2 11 -18 17 C -12 23 -2.2 23 3.4 16"></path><path d="M -7 7.5 L 7 -6.8"></path><path d="M -3.2 -16.8 C 1.8 -22.8 11.8 -22.8 17 -17.8 C 23 -11.8 23 -1.8 17 4.2"></path></svg><span>SEU LINK</span></div>
          </div>
          <div class="sl-thumbs"><button class="sl-add" type="button">＋</button></div>
          <div class="sl-footer">
            <button class="sl-publish" type="button" disabled>PUBLICAR STORY</button>
            <div class="sl-status" role="status"></div>
          </div>
        </div>
        <div class="sl-controls">
          <div class="sl-types">
            <span>▧ POST</span>
            <span>▣ REEL</span>
            <strong>◉ STORY</strong>
            <span class="sl-version-badge">v0.8.0 Multi</span>
          </div>
          <nav class="sl-tabs">
            <button data-tab="general">☷ Geral</button>
            <button data-tab="link" class="active">🔗 Link</button>
            <button data-tab="accounts">👥 Contas</button>
            <button data-tab="highlight">★ Destaque</button>
          </nav>
          <div class="sl-panel" data-panel="general">
            <label><input type="checkbox" class="sl-fill" checked> Preencher a tela</label>
            <p>A imagem é ajustada automaticamente para 9:16.</p>
          </div>
          <div class="sl-panel active" data-panel="link">
            <label>URL<input class="sl-url" type="url" value="https://" placeholder="https://seusite.com"></label>
            <label>Texto do sticker<input class="sl-label" type="text" maxlength="40" value="CLIQUE AQUI | CLICK HERE" placeholder="CLIQUE AQUI"></label>
            <label>Estilo<select class="sl-style"><option value="blue">Azul</option><option value="dark">Preto</option><option value="gradient">Colorido</option></select></label>
            <label class="sl-size-control">Tamanho do sticker<div><span>Pequeno</span><input class="sl-size" type="range" min="70" max="160" value="100" step="1"><span>Grande</span></div><output class="sl-size-output">100%</output></label>
            <p>Arraste o sticker na imagem para posicioná-lo.</p>
          </div>
          <div class="sl-panel" data-panel="accounts">
            <div class="sl-accounts-header">
              <strong>Postar em Múltiplas Contas</strong>
              <p>Poste este mesmo Story com sticker clicável em todas as contas conectadas simultaneamente.</p>
            </div>
            <label class="sl-multicount-check">
              <input type="checkbox" class="sl-post-all" checked> Postar em todas as contas conectadas simultaneamente
            </label>
            <div class="sl-accounts-meta">
              <span class="sl-detected-count">Contas: carregando...</span>
              <button type="button" class="sl-btn-small sl-refresh-accounts">🔄 Atualizar</button>
            </div>
            <div class="sl-accounts-list">
              <div class="sl-accounts-loading">Detectando contas do Instagram Web...</div>
            </div>
            <p class="sl-accounts-tip">💡 Conecte suas contas pelo menu lateral do Instagram Web ("Trocar de conta") para que fiquem disponíveis aqui.</p>
          </div>
          <div class="sl-panel" data-panel="highlight">
            <label class="sl-highlight-check"><input type="checkbox" class="sl-highlight-enabled" checked> Criar Destaque após publicar</label>
            <label>Título do Destaque<input class="sl-highlight-title" type="text" maxlength="30" value="AQUI | HERE" placeholder="Ex.: Links"></label>
            <p>O Story será publicado primeiro e adicionado a um novo Destaque em cada conta selecionada.</p>
          </div>
        </div>
        <input class="sl-file" type="file" accept="image/jpeg,image/png,image/webp" hidden>
      </section>
    </div>`;
  document.documentElement.appendChild(root);

  const $ = (selector) => root.querySelector(selector);
  const menu = $(".sl-create-menu"),
    backdrop = $(".sl-backdrop"),
    file = $(".sl-file"),
    canvas = $(".sl-canvas"),
    photo = $(".sl-photo"),
    sticker = $(".sl-sticker"),
    publish = $(".sl-publish"),
    status = $(".sl-status"),
    url = $(".sl-url"),
    label = $(".sl-label"),
    style = $(".sl-style"),
    size = $(".sl-size"),
    sizeOutput = $(".sl-size-output"),
    highlightEnabled = $(".sl-highlight-enabled"),
    highlightTitle = $(".sl-highlight-title"),
    postAll = $(".sl-post-all"),
    accountsList = $(".sl-accounts-list"),
    detectedCount = $(".sl-detected-count"),
    refreshAccountsBtn = $(".sl-refresh-accounts");

  const stickerMeasureContext = document.createElement("canvas").getContext("2d");

  $(".sl-close").addEventListener("click", close);
  $(".sl-choose").addEventListener("click", () => file.click());
  $(".sl-add").addEventListener("click", () => file.click());
  chrome.runtime.onMessage.addListener((message) => { if (message?.type === "STORYLINK_OPEN") open(); });
  backdrop.addEventListener("click", (event) => { if (event.target === backdrop) close(); });
  menu.querySelectorAll('[data-kind="story"]').forEach((button) => button.addEventListener("click", () => { hideCreateMenu(); open(); }));

  document.addEventListener("click", (event) => {
    if (root.contains(event.target)) return;
    const createTarget = findCreateTarget(event.target);
    if (createTarget) {
      event.preventDefault();
      event.stopPropagation();
      event.stopImmediatePropagation();
      showCreateMenu(createTarget);
      return;
    }
    hideCreateMenu();
  }, true);
  document.addEventListener("keydown", (event) => { if (event.key === "Escape") hideCreateMenu(); });

  root.querySelectorAll(".sl-tabs button").forEach((button) => button.addEventListener("click", () => {
    root.querySelectorAll(".sl-tabs button,.sl-panel").forEach((item) => item.classList.remove("active"));
    button.classList.add("active");
    root.querySelector(`[data-panel="${button.dataset.tab}"]`)?.classList.add("active");
  }));

  file.addEventListener("change", async () => {
    const selected = file.files?.[0]; if (!selected) return;
    setStatus("Preparando imagem…");
    try {
      state.file = selected;
      state.base64 = await prepareImage(selected);
      if (state.imageUrl) URL.revokeObjectURL(state.imageUrl);
      state.imageUrl = URL.createObjectURL(selected);
      photo.src = state.imageUrl;
      canvas.classList.add("ready");
      publish.disabled = false;
      setStatus("");
    } catch (error) { setStatus(error.message, true); }
  });

  label.addEventListener("input", updateSticker);
  url.addEventListener("input", updateSticker);
  style.addEventListener("change", updateSticker);
  size.addEventListener("input", updateSticker);
  highlightEnabled.addEventListener("change", () => {
    highlightTitle.disabled = !highlightEnabled.checked;
    if (highlightEnabled.checked) highlightTitle.focus();
  });

  postAll.addEventListener("change", () => {
    state.postAllAccounts = postAll.checked;
    if (postAll.checked) {
      state.accounts.forEach((acc) => state.selectedAccountIds.add(String(acc.id)));
    }
    renderAccountsList();
    updatePublishButtonText();
  });

  refreshAccountsBtn.addEventListener("click", loadAccounts);

  updateSticker();

  let drag = null;
  sticker.addEventListener("pointerdown", (event) => { drag = event.pointerId; sticker.setPointerCapture(drag); });
  sticker.addEventListener("pointermove", (event) => {
    if (drag !== event.pointerId) return;
    const rect = canvas.getBoundingClientRect();
    state.x = Math.min(.95, Math.max(.05, (event.clientX - rect.left) / rect.width));
    state.y = Math.min(.95, Math.max(.05, (event.clientY - rect.top) / rect.height));
    positionSticker();
  });
  sticker.addEventListener("pointerup", () => { drag = null; });

  publish.addEventListener("click", async () => {
    if (state.busy || !state.base64) return;
    const normalized = normalizeUrl(url.value);
    if (!normalized) return setStatus("Informe um link válido.", true);

    const isMulti = state.postAllAccounts || state.selectedAccountIds.size > 1;
    const targetCount = state.postAllAccounts ? state.accounts.length : state.selectedAccountIds.size;
    const confirmMessage = isMulti && targetCount > 1
      ? `Publicar este Story com link simultaneamente em ${targetCount} contas conectadas?`
      : `Publicar este Story agora com o link ${normalized}?`;

    if (!confirm(confirmMessage)) return;

    state.busy = true;
    publish.disabled = true;
    publish.textContent = "PUBLICANDO…";
    setStatus(isMulti && targetCount > 1 ? `Publicando em ${targetCount} contas conectadas…` : "Enviando ao Instagram…");

    try {
      const finalImage = await prepareImage(state.file, {
        text: sticker.querySelector("span").textContent,
        style: style.value,
        scale: state.stickerScale
      });

      const response = await chrome.runtime.sendMessage({
        type: "STORYLINK_PUBLISH",
        payload: {
          imageBase64: finalImage,
          url: url.value,
          x: state.x,
          y: state.y,
          width: state.width,
          height: state.height,
          createHighlight: highlightEnabled.checked,
          highlightTitle: highlightTitle.value,
          postAllAccounts: state.postAllAccounts,
          accountIds: Array.from(state.selectedAccountIds)
        }
      });

      if (!response?.ok) throw new Error(response?.error || "Falha na publicação.");

      const result = response.result;
      if (result?.multi) {
        const count = result.successCount || 0;
        const total = result.total || 0;
        setStatus(`✅ Story publicado em ${count} de ${total} conta(s) com sucesso!`, false, true);
      } else {
        if (result?.highlightError) {
          setStatus(`Story publicado. Destaque não criado: ${result.highlightError}`, true);
        } else if (highlightEnabled.checked) {
          setStatus("Story publicado e Destaque criado com sucesso!", false, true);
        } else {
          setStatus("Story publicado com sucesso!", false, true);
        }
      }
    } catch (error) {
      setStatus(error.message, true);
    } finally {
      state.busy = false;
      publish.disabled = false;
      updatePublishButtonText();
    }
  });

  function open() {
    backdrop.hidden = false;
    document.documentElement.classList.add("sl-lock");
    loadAccounts();
  }

  function close() {
    backdrop.hidden = true;
    document.documentElement.classList.remove("sl-lock");
  }

  function showCreateMenu(target) {
    const rect = target.getBoundingClientRect();
    menu.style.left = `${Math.max(2, rect.left)}px`;
    menu.style.top = `${Math.min(window.innerHeight - 190, rect.bottom + 6)}px`;
    menu.hidden = false;
  }

  function hideCreateMenu() {
    menu.hidden = true;
  }

  function findCreateTarget(start) {
    let node = start;
    for (let depth = 0; node && depth < 7; depth += 1, node = node.parentElement) {
      const text = (node.textContent || "").trim().replace(/\s+/g, " ");
      if (text === "Criar" && node.getBoundingClientRect().width < 300) return node;
    }
    return null;
  }

  async function loadAccounts() {
    detectedCount.textContent = "Carregando...";
    try {
      const resp = await chrome.runtime.sendMessage({ type: "STORYLINK_GET_ACCOUNTS" });
      if (resp?.ok && Array.isArray(resp.accounts)) {
        state.accounts = resp.accounts;
        resp.accounts.forEach((acc) => state.selectedAccountIds.add(String(acc.id)));
        detectedCount.textContent = `${resp.accounts.length} conta(s) conectada(s)`;
      } else {
        state.accounts = [];
        detectedCount.textContent = "1 conta ativa (padrão)";
      }
    } catch {
      state.accounts = [];
      detectedCount.textContent = "1 conta ativa (padrão)";
    }
    renderAccountsList();
    updatePublishButtonText();
  }

  function renderAccountsList() {
    if (state.accounts.length === 0) {
      accountsList.innerHTML = `
        <div class="sl-account-item is-active">
          <input type="checkbox" checked disabled>
          <div class="sl-acc-info">
            <strong>Conta atual do navegador</strong>
            <span>Sessão ativa no Instagram</span>
          </div>
          <span class="sl-badge-curr">Ativa</span>
        </div>`;
      return;
    }

    accountsList.innerHTML = state.accounts.map((acc) => {
      const id = String(acc.id);
      const isChecked = state.postAllAccounts || state.selectedAccountIds.has(id);
      return `
        <label class="sl-account-item ${acc.isCurrent ? 'is-active' : ''}">
          <input type="checkbox" data-acc-id="${id}" ${isChecked ? 'checked' : ''} ${state.postAllAccounts ? 'disabled' : ''}>
          <div class="sl-acc-avatar">${(acc.username || 'IG')[0].toUpperCase()}</div>
          <div class="sl-acc-info">
            <strong>@${acc.username}</strong>
            <span>${acc.isCurrent ? 'Sessão ativa principal' : 'Conectada no alternador'}</span>
          </div>
          ${acc.isCurrent ? '<span class="sl-badge-curr">Ativa</span>' : ''}
        </label>`;
    }).join("");

    accountsList.querySelectorAll("input[type=checkbox]").forEach((cb) => {
      cb.addEventListener("change", (e) => {
        const id = e.target.dataset.accId;
        if (e.target.checked) state.selectedAccountIds.add(id);
        else state.selectedAccountIds.delete(id);
        updatePublishButtonText();
      });
    });
  }

  function updatePublishButtonText() {
    if (state.busy) return;
    const isMulti = state.postAllAccounts || state.selectedAccountIds.size > 1;
    const count = state.postAllAccounts ? state.accounts.length : state.selectedAccountIds.size;
    if (isMulti && count > 1) {
      publish.textContent = `PUBLICAR EM ${count} CONTAS`;
    } else {
      publish.textContent = "PUBLICAR STORY";
    }
  }

  function positionSticker() {
    sticker.style.left = `${state.x * 100}%`;
    sticker.style.top = `${state.y * 100}%`;
  }

  function updateSticker() {
    let text = label.value.trim();
    if (!text) {
      try { text = new URL(normalizeUrl(url.value)).hostname.replace(/^www\./, "").toUpperCase(); }
      catch { text = "SEU LINK"; }
    }
    const requestedScale = globalThis.StoryLinkSticker?.sliderPercentToScale(size.value) ?? 1;
    if (stickerMeasureContext && globalThis.StoryLinkSticker) {
      stickerMeasureContext.font = "400 34px 'Arial Narrow', 'Roboto Condensed', Arial, sans-serif";
      state.stickerScale = globalThis.StoryLinkSticker.calculateStickerMetrics({
        textWidth: stickerMeasureContext.measureText(text).width,
        scale: requestedScale,
        maxWidth: 842
      }).effectiveScale;
    } else {
      state.stickerScale = requestedScale;
    }
    sizeOutput.value = String(size.value);
    sizeOutput.textContent = `${size.value}%`;
    sticker.querySelector("span").textContent = text;
    sticker.dataset.style = style.value;
    const previewProperties = globalThis.StoryLinkSticker?.createPreviewScaleProperties(state.stickerScale * 100) || { "--sl-sticker-scale": "1" };
    Object.entries(previewProperties).forEach(([property, value]) => sticker.style.setProperty(property, value));
    positionSticker();
  }

  function setStatus(message, error = false, success = false) {
    status.textContent = message || "";
    status.dataset.kind = error ? "error" : success ? "success" : "";
  }

  function normalizeUrl(value) {
    try {
      const raw = value.trim();
      if (!raw) return "";
      return new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`).href;
    } catch {
      return "";
    }
  }

  async function prepareImage(blob, stickerOptions = null) {
    if (blob.size > 20 * 1024 * 1024) throw new Error("A imagem deve ter até 20 MB.");
    const bitmap = await createImageBitmap(blob);
    const output = document.createElement("canvas");
    output.width = 1080;
    output.height = 1920;
    const ctx = output.getContext("2d", { alpha: false });
    ctx.fillStyle = "#000";
    ctx.fillRect(0, 0, 1080, 1920);
    const scale = Math.max(1080 / bitmap.width, 1920 / bitmap.height);
    const w = bitmap.width * scale;
    const h = bitmap.height * scale;
    ctx.drawImage(bitmap, (1080 - w) / 2, (1920 - h) / 2, w, h);
    bitmap.close();
    if (stickerOptions) drawSticker(ctx, stickerOptions);
    return output.toDataURL("image/jpeg", .9).split(",")[1];
  }

  function drawSticker(ctx, options) {
    const centerX = state.x * 1080, centerY = state.y * 1920;
    const text = String(options.text || "SEU LINK").toUpperCase();
    const stickerTools = globalThis.StoryLinkSticker;
    const palette = stickerTools.getStickerPalette(options.style);
    ctx.font = "400 34px 'Arial Narrow', 'Roboto Condensed', Arial, sans-serif";
    const metrics = stickerTools.calculateStickerMetrics({ textWidth: ctx.measureText(text).width, scale: options.scale, maxWidth: 842 });
    const width = metrics.width, height = metrics.height;
    const left = centerX - width / 2, top = centerY - height / 2;
    state.width = width / 1080;
    state.height = height / 1920;

    ctx.save();
    ctx.beginPath();
    ctx.roundRect(left, top, width, height, metrics.radius);
    if (palette.gradient) {
      const gradient = ctx.createLinearGradient(left, top, left + width, top);
      palette.gradient.forEach((color, index) => gradient.addColorStop(index / (palette.gradient.length - 1), color));
      ctx.fillStyle = gradient;
    } else {
      ctx.fillStyle = palette.background;
    }
    ctx.shadowColor = "rgba(0,0,0,.35)";
    ctx.shadowBlur = 22;
    ctx.shadowOffsetY = 8;
    ctx.fill();
    ctx.shadowColor = "transparent";
    ctx.fillStyle = palette.foreground;
    ctx.strokeStyle = palette.foreground;
    drawLinkedChainIcon(ctx, left + metrics.paddingX + metrics.iconSize / 2, centerY, metrics.iconSize);
    ctx.font = `400 ${metrics.fontSize}px 'Arial Narrow', 'Roboto Condensed', Arial, sans-serif`;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(text, left + metrics.paddingX + metrics.iconSize + metrics.iconGap, centerY + 1);
    ctx.restore();
  }

  function drawLinkedChainIcon(ctx, centerX, centerY, size) {
    ctx.save();
    ctx.translate(centerX, centerY);
    ctx.lineWidth = Math.max(2, size * .105);
    ctx.lineCap = "round";
    ctx.lineJoin = "round";
    globalThis.StoryLinkSticker.getLinkedChainPaths(size).forEach((path) => {
      ctx.beginPath();
      path.commands.forEach((command) => ctx[command.op](...command.values));
      ctx.stroke();
    });
    ctx.restore();
  }
})();
