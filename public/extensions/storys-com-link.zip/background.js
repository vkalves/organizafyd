const IG_APP_ID = "936619743392459";

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url?.startsWith("https://www.instagram.com/")) {
    await chrome.tabs.create({ url: "https://www.instagram.com/" });
    return;
  }
  await chrome.tabs.sendMessage(tab.id, { type: "STORYLINK_OPEN" });
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "STORYLINK_GET_ACCOUNTS") {
    getConnectedAccounts()
      .then((data) => sendResponse({ ok: true, ...data }))
      .catch((err) => sendResponse({ ok: false, error: err.message, accounts: [] }));
    return true;
  }

  if (message?.type === "STORYLINK_PUBLISH") {
    handlePublish(message.payload)
      .then((result) => sendResponse({ ok: true, result }))
      .catch((error) => sendResponse({ ok: false, error: explainError(error) }));
    return true;
  }

  return false;
});

async function getConnectedAccounts() {
  const [userCookie, csrfCookie] = await Promise.all([
    chrome.cookies.get({ url: "https://www.instagram.com/", name: "ds_user_id" }),
    chrome.cookies.get({ url: "https://www.instagram.com/", name: "csrftoken" })
  ]);

  const currentUserId = userCookie?.value || null;
  const accountsMap = new Map();

  if (currentUserId) {
    accountsMap.set(String(currentUserId), {
      id: String(currentUserId),
      username: "Conta Atual",
      profilePicUrl: "",
      isCurrent: true
    });
  }

  if (csrfCookie?.value) {
    try {
      const resp = await fetch("https://www.instagram.com/api/v1/web/accounts/account_switcher_info/", {
        method: "GET",
        credentials: "include",
        headers: {
          "accept": "*/*",
          "x-csrftoken": csrfCookie.value,
          "x-ig-app-id": IG_APP_ID
        }
      });
      if (resp.ok) {
        const data = await resp.json();
        const rawAccounts = data?.accounts || data?.users || [];
        rawAccounts.forEach((acc) => {
          const id = String(acc.pk || acc.id || acc.user_id || "");
          if (id) {
            accountsMap.set(id, {
              id,
              username: acc.username || acc.full_name || `id_${id}`,
              profilePicUrl: acc.profile_pic_url || "",
              isCurrent: id === currentUserId
            });
          }
        });
      }
    } catch {
      // Ignore switcher API errors and continue with detected session
    }

    try {
      const familyResp = await fetch("https://www.instagram.com/api/v1/multiple_accounts/get_account_family/", {
        method: "GET",
        credentials: "include",
        headers: {
          "accept": "*/*",
          "x-csrftoken": csrfCookie.value,
          "x-ig-app-id": IG_APP_ID
        }
      });
      if (familyResp.ok) {
        const familyData = await familyResp.json();
        const main = familyData?.main_account;
        const childs = familyData?.child_accounts || [];
        [main, ...childs].filter(Boolean).forEach((acc) => {
          const id = String(acc.pk || acc.id || "");
          if (id) {
            accountsMap.set(id, {
              id,
              username: acc.username || acc.full_name || `id_${id}`,
              profilePicUrl: acc.profile_pic_url || "",
              isCurrent: id === currentUserId
            });
          }
        });
      }
    } catch {
      // Ignore family API errors
    }
  }

  // Load any manually saved accounts in extension storage
  try {
    const stored = await chrome.storage.local.get("saved_accounts");
    if (Array.isArray(stored.saved_accounts)) {
      stored.saved_accounts.forEach((acc) => {
        if (acc?.id && !accountsMap.has(String(acc.id))) {
          accountsMap.set(String(acc.id), {
            id: String(acc.id),
            username: acc.username || `id_${acc.id}`,
            profilePicUrl: acc.profilePicUrl || "",
            isCurrent: String(acc.id) === currentUserId
          });
        }
      });
    }
  } catch {
    // Ignore storage read error
  }

  const list = Array.from(accountsMap.values());
  return { currentUserId, accounts: list };
}

async function handlePublish(payload) {
  if (!payload?.imageBase64) throw new Error("Escolha uma imagem.");
  const link = normalizeUrl(payload.url);
  if (!link) throw new Error("Informe um link válido.");

  const { currentUserId, accounts } = await getConnectedAccounts();

  // If user requested to post to all accounts or selected multiple accounts
  const isMulti = payload.postAllAccounts || (Array.isArray(payload.accountIds) && payload.accountIds.length > 1);

  if (!isMulti || accounts.length <= 1) {
    // Standard single account publish
    return await publishSingleStory(payload, link);
  }

  // Multi-account publish
  const targetAccounts = Array.isArray(payload.accountIds) && payload.accountIds.length > 0
    ? accounts.filter((a) => payload.accountIds.includes(String(a.id)))
    : accounts;

  const results = [];
  const origUserId = currentUserId;

  for (const account of targetAccounts) {
    try {
      if (account.id !== currentUserId) {
        await switchAccount(account.id);
      }
      const singleRes = await publishSingleStory(payload, link);
      results.push({
        accountId: account.id,
        username: account.username,
        ok: true,
        mediaId: singleRes.mediaId,
        highlight: singleRes.highlight,
        highlightError: singleRes.highlightError
      });
    } catch (err) {
      results.push({
        accountId: account.id,
        username: account.username,
        ok: false,
        error: err.message || "Erro ao publicar"
      });
    }
  }

  // Switch back to original user if changed
  if (origUserId && targetAccounts.some((a) => a.id !== origUserId)) {
    try {
      await switchAccount(origUserId);
    } catch {
      // Best effort switch back
    }
  }

  const successCount = results.filter((r) => r.ok).length;
  if (successCount === 0) {
    const firstErr = results[0]?.error || "Falha ao publicar em todas as contas.";
    throw new Error(firstErr);
  }

  return {
    multi: true,
    total: targetAccounts.length,
    successCount,
    results,
    summary: `Publicado com sucesso em ${successCount} de ${targetAccounts.length} conta(s)!`
  };
}

async function switchAccount(targetUserId) {
  const csrfCookie = await chrome.cookies.get({ url: "https://www.instagram.com/", name: "csrftoken" });
  if (!csrfCookie?.value) throw new Error("CSRF token não encontrado.");

  const body1 = new URLSearchParams({ target_user_id: String(targetUserId) });
  const resp1 = await fetch("https://www.instagram.com/api/v1/web/accounts/switch/", {
    method: "POST",
    credentials: "include",
    headers: {
      "accept": "*/*",
      "content-type": "application/x-www-form-urlencoded",
      "x-csrftoken": csrfCookie.value,
      "x-ig-app-id": IG_APP_ID
    },
    body: body1.toString()
  });

  if (resp1.ok) {
    const data = await resp1.json();
    if (data.status === "ok") return data;
  }

  // Fallback to multiple_accounts switch endpoint
  const body2 = new URLSearchParams({ user_id: String(targetUserId) });
  const resp2 = await fetch("https://www.instagram.com/api/v1/multiple_accounts/switch/", {
    method: "POST",
    credentials: "include",
    headers: {
      "accept": "*/*",
      "content-type": "application/x-www-form-urlencoded",
      "x-csrftoken": csrfCookie.value,
      "x-ig-app-id": IG_APP_ID
    },
    body: body2.toString()
  });

  if (resp2.ok) {
    const data = await resp2.json();
    if (data.status === "ok") return data;
  }

  throw new Error(`Não foi possível alternar para a conta ${targetUserId}. Verifique se a conta está salva no alternador do Instagram.`);
}

async function publishSingleStory(payload, link) {
  const [csrfCookie, userCookie, uuidCookie] = await Promise.all([
    chrome.cookies.get({ url: "https://www.instagram.com/", name: "csrftoken" }),
    chrome.cookies.get({ url: "https://www.instagram.com/", name: "ds_user_id" }),
    chrome.cookies.get({ url: "https://www.instagram.com/", name: "ig_did" })
  ]);
  if (!csrfCookie?.value) throw new Error("Sessão não encontrada. Atualize o Instagram e entre novamente.");

  const bytes = base64ToBytes(payload.imageBase64);
  const uploadId = String(Date.now());
  const uploadName = `story_${uploadId}`;
  const uploadResponse = await fetch(`https://i.instagram.com/rupload_igphoto/${uploadName}`, {
    method: "POST",
    credentials: "include",
    headers: {
      "accept": "*/*",
      "offset": "0",
      "x-entity-name": uploadName,
      "x-entity-length": String(bytes.byteLength),
      "x-ig-app-id": IG_APP_ID,
      "x-instagram-rupload-params": JSON.stringify({
        upload_id: uploadId,
        media_type: 1,
        upload_media_width: 1080,
        upload_media_height: 1920
      })
    },
    body: bytes
  });
  await requireSuccess(uploadResponse, "envio da imagem");

  const sticker = {
    x: clamp(payload.x, 0.05, 0.95),
    y: clamp(payload.y, 0.05, 0.95),
    width: clamp(payload.width, 0.1, 0.9),
    height: clamp(payload.height, 0.03, 0.3),
    rotation: 0,
    link_type: "web",
    url: link
  };
  const body = new URLSearchParams({
    upload_id: uploadId,
    story_link_stickers: JSON.stringify([sticker])
  });

  const configureResponse = await fetch("https://www.instagram.com/api/v1/web/create/configure_to_story/", {
    method: "POST",
    credentials: "include",
    headers: {
      "accept": "*/*",
      "content-type": "application/x-www-form-urlencoded",
      "x-csrftoken": csrfCookie.value,
      "x-ig-app-id": IG_APP_ID
    },
    body: body.toString()
  });
  const result = await requireSuccess(configureResponse, "publicação do Story");
  const mediaId = result.media?.pk || result.media?.id || null;
  let highlight = null;
  let highlightError = null;
  if (payload.createHighlight) {
    if (!mediaId) highlightError = "O Instagram publicou o Story, mas não retornou o ID necessário para criar o Destaque.";
    else {
      try {
        highlight = await createHighlight({
          mediaId: String(mediaId),
          title: String(payload.highlightTitle || "Destaque").trim().slice(0, 30) || "Destaque",
          csrf: csrfCookie.value,
          userId: userCookie?.value || "",
          uuid: uuidCookie?.value || crypto.randomUUID()
        });
      } catch (error) { highlightError = error.message; }
    }
  }
  return { mediaId, highlight, highlightError };
}

async function createHighlight({ mediaId, title, csrf, userId, uuid }) {
  const body = new URLSearchParams({
    source: "self_profile",
    creation_id: String(Date.now()),
    _csrftoken: csrf,
    _uid: userId,
    _uuid: uuid,
    cover: JSON.stringify({ media_id: mediaId }),
    title,
    media_ids: JSON.stringify([mediaId])
  });
  const response = await fetch("https://www.instagram.com/api/v1/highlights/create_reel/", {
    method: "POST",
    credentials: "include",
    headers: {
      "accept": "*/*",
      "content-type": "application/x-www-form-urlencoded",
      "x-csrftoken": csrf,
      "x-ig-app-id": IG_APP_ID
    },
    body: body.toString()
  });
  return requireSuccess(response, "criação do Destaque");
}

async function requireSuccess(response, stage) {
  const text = await response.text();
  let data = {};
  try { data = JSON.parse(text); } catch { data = { message: text.slice(0, 240) }; }
  if (!response.ok || (data.status && data.status !== "ok")) {
    const detail = data.message || data.error_type || `HTTP ${response.status}`;
    const error = new Error(`${stage}: ${detail}`);
    error.status = response.status;
    throw error;
  }
  return data;
}

function normalizeUrl(value) {
  try {
    const candidate = /^https?:\/\//i.test(value.trim()) ? value.trim() : `https://${value.trim()}`;
    const url = new URL(candidate);
    return ["http:", "https:"].includes(url.protocol) ? url.href : "";
  } catch { return ""; }
}

function base64ToBytes(base64) {
  const binary = atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function clamp(value, min, max) {
  const number = Number(value);
  return Math.min(max, Math.max(min, Number.isFinite(number) ? number : 0.5));
}

function explainError(error) {
  if (error?.status === 401 || error?.status === 403) return "O Instagram recusou a sessão. Atualize a página e entre novamente.";
  return error?.message || "Não foi possível publicar o Story.";
}
