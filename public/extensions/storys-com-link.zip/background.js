const ANDROID_UA =
  "Instagram 317.0.0.34.109 Android (33/13; 420dpi; 1080x2400; samsung; SM-G991B; o1s; exynos2100; pt_BR; 562259133)";
const ANDROID_APP_ID = "567067343352427";
const WEB_APP_ID = "936619743392459";

function randomUuid() {
  if (crypto && crypto.randomUUID) return crypto.randomUUID();
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    const v = c === "x" ? r : (r & 0x3) | 0x8;
    return v.toString(16);
  });
}

function base64ToUint8Array(dataUrlOrBase64) {
  const base64 = dataUrlOrBase64.includes(",")
    ? dataUrlOrBase64.split(",")[1]
    : dataUrlOrBase64;
  const bin = atob(base64);
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) {
    bytes[i] = bin.charCodeAt(i);
  }
  return bytes;
}

function drawRoundedRectPath(ctx, x, y, width, height, radius) {
  const r = Math.min(radius, width / 2, height / 2);
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + width, y, x + width, y + height, r);
  ctx.arcTo(x + width, y + height, x, y + height, r);
  ctx.arcTo(x, y + height, x, y, r);
  ctx.arcTo(x, y, x + width, y, r);
  ctx.closePath();
}

function drawChainLinkIcon(ctx, cx, cy, scaleFactor, color) {
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-Math.PI / 4);
  const s = (scaleFactor * 36) / 24;
  ctx.scale(s, s);
  ctx.translate(-12, -12);
  ctx.strokeStyle = color;
  ctx.lineWidth = 2.5;
  ctx.lineCap = "round";
  ctx.lineJoin = "round";
  if (typeof Path2D !== "undefined") {
    ctx.stroke(new Path2D("M9 17H7A5 5 0 0 1 7 7h2"));
    ctx.stroke(new Path2D("M15 7h2a5 5 0 1 1 0 10h-2"));
    ctx.stroke(new Path2D("M8 12h8"));
  } else {
    ctx.beginPath();
    ctx.arc(12, 12, 6, 0, Math.PI * 2);
    ctx.stroke();
  }
  ctx.restore();
}

// Failsafe in Service Worker: if caller did not already bake the visual sticker onto the JPEG,
// bake it using OffscreenCanvas before uploading to Instagram!
async function ensureStickerBakedBytes(payload) {
  const rawBytes = base64ToUint8Array(payload.imageBase64);
  if (payload.stickerBaked === true) {
    return rawBytes;
  }
  if (typeof OffscreenCanvas === "undefined" || typeof createImageBitmap === "undefined") {
    return rawBytes;
  }
  try {
    const blobIn = new Blob([rawBytes], { type: "image/jpeg" });
    const bmp = await createImageBitmap(blobIn);
    const canvas = new OffscreenCanvas(1080, 1920);
    const ctx = canvas.getContext("2d");
    const scale = Math.max(1080 / bmp.width, 1920 / bmp.height);
    const w = bmp.width * scale;
    const h = bmp.height * scale;
    ctx.drawImage(bmp, (1080 - w) / 2, (1920 - h) / 2, w, h);

    const label = String(payload.stickerText || "CLIQUE AQUI").trim().toUpperCase();
    const scaleFactor = Number(payload.stickerSize || 92) / 100;
    const fontSize = Math.round(38 * scaleFactor);
    ctx.font = `700 ${fontSize}px sans-serif`;
    const textW = ctx.measureText(label).width;
    const iconSpace = Math.round(56 * scaleFactor);
    const padX = Math.round(42 * scaleFactor);
    const pillW = Math.min(980, Math.round(textW + iconSpace + padX * 2));
    const pillH = Math.round(106 * scaleFactor);
    const cx = Number(payload.xNorm ?? 0.5) * 1080;
    const cy = Number(payload.yNorm ?? 0.74) * 1920;
    const pillX = Math.max(24, Math.min(1080 - pillW - 24, cx - pillW / 2));
    const pillY = Math.max(24, Math.min(1920 - pillH - 24, cy - pillH / 2));

    const st = payload.stickerStyle || "blue";
    const bg = st === "dark" ? "rgba(18,18,22,0.92)" : "#ffffff";
    const fg =
      st === "blue"
        ? "#1d6ff2"
        : st === "white"
          ? "#18181b"
          : st === "pink"
            ? "#e11d48"
            : st === "green"
              ? "#059669"
              : "#ffffff";

    ctx.save();
    ctx.shadowColor = "rgba(0,0,0,0.32)";
    ctx.shadowBlur = 26;
    ctx.shadowOffsetY = 8;
    ctx.fillStyle = bg;
    drawRoundedRectPath(ctx, pillX, pillY, pillW, pillH, pillH / 2);
    ctx.fill();
    ctx.restore();

    drawChainLinkIcon(
      ctx,
      pillX + padX + Math.round(18 * scaleFactor),
      pillY + pillH / 2,
      scaleFactor,
      fg
    );

    ctx.save();
    ctx.fillStyle = fg;
    ctx.font = `700 ${fontSize}px sans-serif`;
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(label, pillX + padX + iconSpace, pillY + pillH / 2 + 2);
    ctx.restore();

    const outBlob = await canvas.convertToBlob({ type: "image/jpeg", quality: 0.94 });
    const ab = await outBlob.arrayBuffer();
    return new Uint8Array(ab);
  } catch {
    return rawBytes;
  }
}

function sanitizeError(rawText, status) {
  if (!rawText) return "Erro HTTP " + status + " ao comunicar com o Instagram.";
  if (
    rawText.includes("<!DOCTYPE html>") ||
    rawText.includes("<html") ||
    rawText.includes("Page Not Found") ||
    rawText.includes("not-logged-in")
  ) {
    return (
      "Sessão do Instagram não autorizada (HTTP " +
      status +
      "). Verifique se você está logado em www.instagram.com neste navegador e atualize a página."
    );
  }
  try {
    const parsed = JSON.parse(rawText);
    return parsed.message || parsed.error_title || rawText;
  } catch {
    return rawText.slice(0, 240);
  }
}

async function setupInstagramMobileRules() {
  const cookies = await chrome.cookies.getAll({ domain: "instagram.com" });
  const cookieMap = {};
  for (const c of cookies) {
    cookieMap[c.name] = c.value;
  }

  const sessionId = cookieMap["sessionid"] || "";
  const dsUserId = cookieMap["ds_user_id"] || "";
  const csrfToken = cookieMap["csrftoken"] || "";
  const mid = cookieMap["mid"] || "";
  const igDid = cookieMap["ig_did"] || randomUuid().toUpperCase();

  if (!sessionId || !dsUserId) {
    throw new Error(
      "Você não está logado no Instagram neste navegador. Abra www.instagram.com, faça login na conta e tente novamente."
    );
  }

  const cookieHeader = cookies.map((c) => `${c.name}=${c.value}`).join("; ");

  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1001, 1002],
    addRules: [
      {
        id: 1001,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "User-Agent", operation: "set", value: ANDROID_UA },
            { header: "Cookie", operation: "set", value: cookieHeader },
            { header: "X-IG-App-ID", operation: "set", value: ANDROID_APP_ID },
            { header: "X-IG-Capabilities", operation: "set", value: "3brTv10=" },
            { header: "X-IG-Connection-Type", operation: "set", value: "WIFI" },
            { header: "X-IG-App-Locale", operation: "set", value: "pt_BR" },
            { header: "X-IG-Device-Locale", operation: "set", value: "pt_BR" },
            { header: "Accept-Language", operation: "set", value: "pt-BR, en-US" },
            { header: "Origin", operation: "remove" },
            { header: "Referer", operation: "remove" }
          ]
        },
        condition: {
          urlFilter: "||i.instagram.com/",
          resourceTypes: ["xmlhttprequest", "other"]
        }
      },
      {
        id: 1002,
        priority: 1,
        action: {
          type: "modifyHeaders",
          requestHeaders: [
            { header: "User-Agent", operation: "set", value: ANDROID_UA },
            { header: "Cookie", operation: "set", value: cookieHeader },
            { header: "X-IG-App-ID", operation: "set", value: WEB_APP_ID },
            { header: "X-CSRFToken", operation: "set", value: csrfToken },
            { header: "X-Requested-With", operation: "set", value: "XMLHttpRequest" }
          ]
        },
        condition: {
          urlFilter: "||www.instagram.com/api/v1/media/configure_to_story",
          resourceTypes: ["xmlhttprequest", "other"]
        }
      }
    ]
  });

  return { sessionId, dsUserId, csrfToken, mid, igDid };
}

async function handlePublishStoryWithLink(payload) {
  const {
    linkUrl,
    stickerText,
    xNorm = 0.5,
    yNorm = 0.74,
    widthNorm = 0.52,
    heightNorm = 0.09,
    highlightTitle = ""
  } = payload;

  const { dsUserId, csrfToken, mid, igDid } = await setupInstagramMobileRules();
  const bytes = await ensureStickerBakedBytes(payload);
  const uploadId = String(Date.now());
  const entityName = `fb_uploader_${uploadId}`;
  const clientUuid = igDid.toLowerCase();
  const nowSec = Math.floor(Date.now() / 1000);
  const tzOffset = String(-new Date().getTimezoneOffset() * 60);

  const ruploadParams = JSON.stringify({
    media_type: 1,
    upload_id: uploadId,
    upload_media_height: 1920,
    upload_media_width: 1080,
    xsharing_user_ids: "[]",
    image_compression: JSON.stringify({
      lib_name: "moz",
      lib_version: "3.1.m",
      quality: "92"
    })
  });

  const mobileHeaders = {
    "X-IG-App-ID": ANDROID_APP_ID,
    "X-IG-Device-ID": clientUuid,
    "X-IG-Family-Device-ID": clientUuid,
    "X-IG-Android-ID": "android-" + clientUuid.replace(/-/g, "").slice(0, 16),
    "X-IG-Timezone-Offset": tzOffset,
    "X-IG-Capabilities": "3brTv10=",
    "X-IG-Connection-Type": "WIFI",
    "X-CSRFToken": csrfToken,
    ...(mid ? { "X-MID": mid } : {})
  };

  // 1. Upload JPEG (with sticker baked onto pixels!) to i.instagram.com/rupload_igphoto/
  const uploadRes = await fetch(
    `https://i.instagram.com/rupload_igphoto/${entityName}`,
    {
      method: "POST",
      credentials: "include",
      headers: {
        ...mobileHeaders,
        "X-Entity-Name": entityName,
        "X-Entity-Length": String(bytes.byteLength),
        "X-Entity-Type": "image/jpeg",
        "X-Instagram-Rupload-Params": ruploadParams,
        Offset: "0",
        "Content-Type": "application/octet-stream"
      },
      body: bytes
    }
  );

  const uploadText = await uploadRes.text();
  if (!uploadRes.ok || uploadText.includes("<!DOCTYPE html>")) {
    throw new Error(
      "Falha no upload da imagem: " + sanitizeError(uploadText, uploadRes.status)
    );
  }

  // 2. Validate Link URL
  const validateData = {
    url: linkUrl,
    _uid: String(dsUserId),
    _uuid: clientUuid
  };
  try {
    await fetch("https://i.instagram.com/api/v1/media/validate_reel_url/", {
      method: "POST",
      credentials: "include",
      headers: {
        ...mobileHeaders,
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
      },
      body:
        "signed_body=SIGNATURE." + encodeURIComponent(JSON.stringify(validateData))
    });
  } catch {}

  // 3. Build tap_models + story_link_stickers + story_cta at the exact sticker coordinates
  let host = "link";
  try {
    host = new URL(linkUrl).hostname.replace(/^www\./, "");
  } catch {}

  const rx = Number(Number(xNorm).toFixed(7));
  const ry = Number(Number(yNorm).toFixed(7));
  const rw = Number(Number(widthNorm).toFixed(7));
  const rh = Number(Number(heightNorm).toFixed(7));

  const tapModels = [
    {
      x: rx,
      y: ry,
      z: 0,
      width: rw,
      height: rh,
      rotation: 0.0,
      type: "story_link",
      is_sticker: true,
      selected_index: 0,
      tap_state: 0,
      link_type: "web",
      url: linkUrl,
      tap_state_str_id: "link_sticker_default",
      custom_cta: stickerText,
      link_title: stickerText,
      display_url: host
    }
  ];

  const storyLinkStickers = [
    {
      x: rx,
      y: ry,
      z: 0,
      width: rw,
      height: rh,
      rotation: 0.0,
      story_link: {
        link_type: "web",
        url: linkUrl,
        link_title: stickerText,
        display_url: host,
        custom_cta: stickerText
      }
    }
  ];

  const storyCta = [
    {
      links: [
        {
          webUri: linkUrl,
          linkType: 1
        }
      ]
    }
  ];

  const configureData = {
    upload_id: uploadId,
    timezone_offset: tzOffset,
    client_shared_at: String(nowSec - 3),
    client_timestamp: String(nowSec),
    story_sticker_ids: "link_sticker_default",
    media_folder: "Camera",
    configure_mode: "1",
    source_type: "4",
    creation_surface: "camera",
    imported_taken_at: nowSec - 3600,
    capture_type: "normal",
    original_media_type: "photo",
    _uid: String(dsUserId),
    _uuid: clientUuid,
    device_id: "android-" + clientUuid.replace(/-/g, "").slice(0, 16),
    composition_id: randomUuid(),
    media_transformation_info: JSON.stringify({
      width: "1080",
      height: "1920",
      x_transform: "0",
      y_transform: "0",
      zoom: "1.0",
      rotation: "0.0",
      background_coverage: "0.0"
    }),
    edits: {
      crop_original_size: [1080.0, 1920.0],
      filter_type: 0,
      filter_strength: 1.0
    },
    extra: {
      source_width: 1080,
      source_height: 1920
    },
    tap_models: JSON.stringify(tapModels),
    story_link_stickers: JSON.stringify(storyLinkStickers),
    story_cta: JSON.stringify(storyCta)
  };

  const signedBody =
    "signed_body=SIGNATURE." + encodeURIComponent(JSON.stringify(configureData));

  const configEndpoints = [
    "https://i.instagram.com/api/v1/media/configure_to_story/",
    "https://www.instagram.com/api/v1/media/configure_to_story/"
  ];

  let publishedMedia = null;
  let lastError = "";

  for (const endpoint of configEndpoints) {
    const res = await fetch(endpoint, {
      method: "POST",
      credentials: "include",
      headers: {
        ...mobileHeaders,
        "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
      },
      body: signedBody
    });

    const txt = await res.text();
    if (res.ok && !txt.includes("<!DOCTYPE html>")) {
      try {
        const json = JSON.parse(txt);
        if (json && (json.status === "ok" || json.media)) {
          publishedMedia = json.media || json;
          break;
        }
        lastError = json.message || txt;
      } catch {
        lastError = sanitizeError(txt, res.status);
      }
    } else {
      lastError = sanitizeError(txt, res.status);
    }
  }

  if (!publishedMedia) {
    throw new Error(
      "Publicação do Story: " + (lastError || "Falha ao configurar sticker de link.")
    );
  }

  if (highlightTitle && publishedMedia.id) {
    try {
      const hlData = {
        source: "story_viewer_default",
        media_ids: JSON.stringify([String(publishedMedia.id)]),
        title: highlightTitle,
        _uid: String(dsUserId),
        _uuid: clientUuid
      };
      await fetch(
        `https://i.instagram.com/api/v1/highlights/${dsUserId}/create_reel/`,
        {
          method: "POST",
          credentials: "include",
          headers: {
            ...mobileHeaders,
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
          },
          body: "signed_body=SIGNATURE." + encodeURIComponent(JSON.stringify(hlData))
        }
      );
    } catch {}
  }

  return {
    ok: true,
    mediaId: publishedMedia.id || publishedMedia.pk || uploadId
  };
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "ORGANIZAFY_PING_EXTENSION") {
    sendResponse({ ok: true, version: "0.7.0" });
    return true;
  }

  if (msg && msg.type === "PUBLISH_IG_STORY_WITH_LINK") {
    handlePublishStoryWithLink(msg.payload)
      .then((res) => sendResponse({ ok: true, ...res }))
      .catch((err) =>
        sendResponse({
          ok: false,
          error: err instanceof Error ? err.message : String(err)
        })
      );
    return true;
  }
  return false;
});

chrome.action.onClicked.addListener(async (tab) => {
  if (!tab.id || !tab.url || !tab.url.startsWith("https://www.instagram.com")) {
    await chrome.tabs.create({
      url: "https://www.instagram.com/?story_link_editor=1"
    });
    return;
  }
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    files: ["content.js"]
  });
  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      window.dispatchEvent(new CustomEvent("organizafy:toggle-story-link-modal"));
    }
  });
});
