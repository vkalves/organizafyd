import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Underline from "@tiptap/extension-underline";
import LinkExt from "@tiptap/extension-link";
import Placeholder from "@tiptap/extension-placeholder";
import TaskList from "@tiptap/extension-task-list";
import TaskItem from "@tiptap/extension-task-item";
import { DOMSerializer } from "@tiptap/pm/model";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Bold,
  CheckSquare,
  Code,
  Eraser,
  ExternalLink,
  Heading1,
  Heading2,
  Heading3,
  Italic,
  Link2,
  List,
  ListOrdered,
  Minus,
  Pilcrow,
  Quote,
  Redo,
  Strikethrough,
  Underline as UnderlineIcon,
  Undo,
} from "lucide-react";
import { cn } from "@/lib/utils";

interface RichTextEditorProps {
  content: string;
  readOnly?: boolean;
  onChange: (html: string) => void;
  onChecklistChange?: (html: string) => void;
  placeholder?: string;
  className?: string;
}

interface EditorToolButtonProps {
  active?: boolean;
  disabled?: boolean;
  onClick: () => void;
  children: React.ReactNode;
  title: string;
}

function EditorToolButton({
  active,
  disabled,
  onClick,
  children,
  title,
}: EditorToolButtonProps) {
  return (
    <button
      type="button"
      disabled={disabled}
      onClick={onClick}
      title={title}
      aria-label={title}
      aria-pressed={active}
      className={cn(
        "flex h-9 w-9 shrink-0 touch-manipulation items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-accent hover:text-foreground disabled:pointer-events-none disabled:opacity-35",
        active && "bg-accent text-foreground",
      )}
    >
      {children}
    </button>
  );
}

function ToolDivider() {
  return <div className="mx-1 h-5 w-px shrink-0 bg-border" />;
}

export function RichTextEditor({
  content,
  onChange,
  onChecklistChange,
  placeholder = "Escreva sua nota...",
  className,
  readOnly = false,
}: RichTextEditorProps) {
  const [plainText, setPlainText] = useState("");

  const editor = useEditor({
    shouldRerenderOnTransaction: true,
    editable: !readOnly,
    extensions: [
      StarterKit.configure({
        heading: { levels: [1, 2, 3] },
        link: false,
        underline: false,
      }),
      Underline,
      LinkExt.extend({
        inclusive: false,
        renderHTML(props) {
          // Keep the built-in URL validation and the full editable text.
          const rendered = this.parent?.(props) as [string, Record<string, string>, number];
          return [
            rendered[0],
            { ...rendered[1], title: rendered[1].href ? `${rendered[1].href} · Ctrl/Cmd + clique para abrir` : "Link" },
            ["span", { class: "note-link-label" }, 0],
          ];
        },
      }).configure({
        openOnClick: false,
        autolink: true,
        linkOnPaste: true,
        defaultProtocol: "https",
        HTMLAttributes: {
          class: "note-link-mention",
          title: "Abrir link em outra aba",
          rel: "noopener noreferrer",
          target: "_blank",
        },
      }),
      Placeholder.configure({ placeholder }),
      TaskList,
      TaskItem.configure({
        nested: true,
        // Keep checklist items actionable while the note is in "Visualizar".
        // The DOM change handler below mirrors the checkbox state into the
        // ProseMirror document so the normal autosave flow can persist it.
        onReadOnlyChecked: () => true,
      }),
    ],
    content: content || "",
    onCreate: ({ editor }) => setPlainText(editor.getText()),
    onUpdate: ({ editor }) => {
      setPlainText(editor.getText());
      onChange(editor.getHTML());
    },
    editorProps: {
      handleDOMEvents: {
        change: (view, event) => {
          // Tiptap intentionally keeps task checkboxes immutable in read-only
          // mode unless onReadOnlyChecked is provided. In Visualizar mode we
          // still want checklist actions to work without making text editable.
          if (view.editable) return false;

          const checkbox = event.target;
          if (!(checkbox instanceof HTMLInputElement) || checkbox.type !== "checkbox") return false;

          const taskItem = checkbox.closest('li[data-type="taskItem"]');
          if (!taskItem) return false;

          // Keep the visual state in sync immediately in inspection mode.
          taskItem.setAttribute("data-checked", String(checkbox.checked));

          // Build clean HTML from the ProseMirror document, then copy the
          // live checkbox states into it. In read-only mode Tiptap intentionally
          // does not write checkbox clicks back to the document, so waiting for
          // editor.getHTML() would lose the selection.
          const container = document.createElement("div");
          const fragment = DOMSerializer.fromSchema(view.state.schema)
            .serializeFragment(view.state.doc.content);
          container.appendChild(fragment);

          const liveItems = Array.from(
            view.dom.querySelectorAll<HTMLLIElement>('li[data-type="taskItem"]'),
          );
          const savedItems = Array.from(
            container.querySelectorAll<HTMLLIElement>('li[data-type="taskItem"]'),
          );

          liveItems.forEach((liveItem, index) => {
            const savedItem = savedItems[index];
            if (!savedItem) return;

            const liveCheckbox = liveItem.querySelector<HTMLInputElement>('input[type="checkbox"]');
            const savedCheckbox = savedItem.querySelector<HTMLInputElement>('input[type="checkbox"]');
            if (!liveCheckbox) return;

            savedItem.setAttribute("data-checked", String(liveCheckbox.checked));

            if (savedCheckbox) {
              if (liveCheckbox.checked) {
                savedCheckbox.setAttribute("checked", "checked");
              } else {
                savedCheckbox.removeAttribute("checked");
              }
            }
          });

          onChecklistChange?.(container.innerHTML);
          return false;
        },
      },
      handleClick: (_view, _pos, event) => {
        if ((!readOnly && !(event.ctrlKey || event.metaKey)) || event.button !== 0) return false;
        const target = event.target;
        const link = target instanceof Element ? target.closest("a.note-link-mention") : null;
        const href = link?.getAttribute("href");
        if (!href || !/^(https?:|mailto:|tel:)/i.test(href)) return false;
        event.preventDefault();
        window.open(href, "_blank", "noopener,noreferrer");
        return true;
      },
      attributes: {
        class:
          "prose prose-invert prose-sm min-h-full max-w-none [overflow-wrap:anywhere] px-4 py-5 text-foreground focus:outline-none sm:px-6 sm:py-6",
      },
    },
  });

  useEffect(() => {
    editor?.setEditable(!readOnly, false);
  }, [editor, readOnly]);

  useEffect(() => {
    if (editor && content !== editor.getHTML()) {
      editor.commands.setContent(content || "", { emitUpdate: false });
      setPlainText(editor.getText());
    }
  }, [content, editor]);

  const stats = useMemo(() => {
    const text = plainText.trim();
    return {
      words: text ? text.split(/\s+/).length : 0,
      characters: plainText.length,
    };
  }, [plainText]);

  const editLink = useCallback(() => {
    if (!editor) return;

    const currentHref = editor.getAttributes("link").href || "";
    const url = window.prompt(
      currentHref
        ? "Edite o link. Deixe vazio para remover:"
        : "Cole ou digite a URL:",
      currentHref,
    );

    if (url === null) return;

    if (!url.trim()) {
      editor.chain().focus().extendMarkRange("link").unsetLink().run();
      return;
    }

    const normalized = /^https?:\/\//i.test(url.trim())
      ? url.trim()
      : `https://${url.trim()}`;

    editor.chain().focus().extendMarkRange("link").setLink({ href: normalized }).run();
  }, [editor]);

  const clearFormatting = useCallback(() => {
    if (!editor) return;
    editor.chain().focus().unsetAllMarks().clearNodes().run();
  }, [editor]);

  if (!editor) return null;

  return (
    <div
      className={cn(
        "flex min-h-[20rem] min-w-0 flex-col overflow-hidden rounded-xl border border-border bg-secondary",
        className,
      )}
    >
      {!readOnly && <div
        className="scrollbar-none flex shrink-0 flex-nowrap items-center gap-0.5 overflow-x-auto overscroll-x-contain border-b border-border bg-secondary/85 p-1.5"
        role="toolbar"
        aria-label="Ferramentas de formatação"
      >
        <EditorToolButton
          active={editor.isActive("paragraph")}
          onClick={() => editor.chain().focus().setParagraph().run()}
          title="Parágrafo"
        >
          <Pilcrow className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("heading", { level: 1 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
          title="Título 1"
        >
          <Heading1 className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("heading", { level: 2 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
          title="Título 2"
        >
          <Heading2 className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("heading", { level: 3 })}
          onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
          title="Título 3"
        >
          <Heading3 className="h-4 w-4" />
        </EditorToolButton>

        <ToolDivider />

        <EditorToolButton
          active={editor.isActive("bold")}
          onClick={() => editor.chain().focus().toggleBold().run()}
          title="Negrito · Ctrl+B"
        >
          <Bold className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("italic")}
          onClick={() => editor.chain().focus().toggleItalic().run()}
          title="Itálico · Ctrl+I"
        >
          <Italic className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("underline")}
          onClick={() => editor.chain().focus().toggleUnderline().run()}
          title="Sublinhado · Ctrl+U"
        >
          <UnderlineIcon className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("strike")}
          onClick={() => editor.chain().focus().toggleStrike().run()}
          title="Riscado"
        >
          <Strikethrough className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("code")}
          onClick={() => editor.chain().focus().toggleCode().run()}
          title="Código inline"
        >
          <Code className="h-4 w-4" />
        </EditorToolButton>

        <ToolDivider />

        <EditorToolButton
          active={editor.isActive("bulletList")}
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          title="Lista"
        >
          <List className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("orderedList")}
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          title="Lista numerada"
        >
          <ListOrdered className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("taskList")}
          onClick={() => editor.chain().focus().toggleTaskList().run()}
          title="Checklist"
        >
          <CheckSquare className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          active={editor.isActive("blockquote")}
          onClick={() => editor.chain().focus().toggleBlockquote().run()}
          title="Citação"
        >
          <Quote className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          onClick={() => editor.chain().focus().setHorizontalRule().run()}
          title="Separador"
        >
          <Minus className="h-4 w-4" />
        </EditorToolButton>

        <ToolDivider />

        <EditorToolButton
          active={editor.isActive("link")}
          onClick={editLink}
          title={editor.isActive("link") ? "Editar/remover link" : "Adicionar link"}
        >
          <Link2 className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          disabled={!editor.isActive("link")}
          onClick={() => {
            const href = editor.getAttributes("link").href;
            if (typeof href === "string" && /^(https?:|mailto:|tel:)/i.test(href)) {
              window.open(href, "_blank", "noopener,noreferrer");
            }
          }}
          title="Abrir link selecionado em outra aba"
        >
          <ExternalLink className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          onClick={clearFormatting}
          title="Limpar formatação"
        >
          <Eraser className="h-4 w-4" />
        </EditorToolButton>

        <ToolDivider />

        <EditorToolButton
          disabled={!editor.can().chain().focus().undo().run()}
          onClick={() => editor.chain().focus().undo().run()}
          title="Desfazer · Ctrl+Z"
        >
          <Undo className="h-4 w-4" />
        </EditorToolButton>
        <EditorToolButton
          disabled={!editor.can().chain().focus().redo().run()}
          onClick={() => editor.chain().focus().redo().run()}
          title="Refazer · Ctrl+Shift+Z"
        >
          <Redo className="h-4 w-4" />
        </EditorToolButton>
      </div>}

      <EditorContent
        editor={editor}
        onWheel={(event) => event.stopPropagation()}
        className="min-h-0 flex-1 touch-pan-y overflow-y-auto overscroll-contain bg-secondary"
      />

      <div className="flex shrink-0 items-center justify-between gap-3 border-t border-border bg-secondary/70 px-3 py-2 text-[10px] text-muted-foreground sm:px-4">
        <span>{stats.words} {stats.words === 1 ? "palavra" : "palavras"} · {stats.characters} caracteres</span>
        <span className="hidden sm:inline">{readOnly ? "Somente leitura" : "Ctrl+S para salvar"}</span>
      </div>
    </div>
  );
}
